package com.company.model;

public enum TypeNumber {
    ARABIC, ROMAN
}
